# SocketCAN 网关使用指南

## 概述
本网关实现 SocketCAN 到 UCAN2 硬件（USB-CAN 适配器）的双向数据转发。  
- 从 `vcan_tx` 接收用户发送的 CAN 帧，转发至 UCAN2 并输出到物理 CAN 总线。  
- 从 UCAN2 接收物理 CAN 总线上的帧，转发至 `vcan_rx`，用户可通过 `candump` 或 `tcpdump` 接收。

## 快速开始（正常使用）

### 1. 启动网关服务
```bash
sudo systemctl start socketcan-gateway

### 2. 发送测试数据（用户 → 硬件）
bash
cansend vcan_tx 123#1122334455667788
该命令向 vcan_tx 接口发送一个标准 CAN 帧（ID=0x123，数据 8 字节）。

网关收到后会将帧转发至 UCAN2 硬件，再由硬件发送到真实 CAN 总线。

### 3. 接收硬件发来的数据（硬件 → 用户）
bash
# 方法一：使用 tcpdump（需 root）
sudo tcpdump -i vcan_rx -v

# 方法二：使用 candump（更直观）
candump vcan_rx
当 UCAN2 从 CAN 总线收到帧时，网关会将其写入 vcan_rx 接口，上述命令即可显示收到的帧。

### 完整测试流程（验证网关工作正常）
# 开启一个终端，实时查看网关日志
bash
journalctl -u socketcan-gateway -f

# 开启第二个终端，监听接收接口
bash
sudo tcpdump -i vcan_rx -v

# 开启第三个终端，发送一帧数据
bash
cansend vcan_tx 123#1122334455667788

# 预期结果

网关日志 会显示：

text
→→→ [用户→vcan_tx→UCAN2] #1
     CAN ID: 0x123, DLC: 8
     数据: 11 22 33 44 55 66 77 88
     ✅ 已发送到UCAN2
←←← [硬件→UCAN2→vcan_rx→用户] 帧ID:0x123 DLC:8
     数据: 11 22 33 44 55 66 77 88
tcpdump / candump 会立即显示收到的帧，内容与发送的完全一致。

注意：如果未出现 ←←← 条目，表明 UCAN2 没有从 CAN 总线收到回复帧（可能是总线上无其他节点或未开启回环）。但 →→→ 出现说明网关已正确接收并转发了用户数据，网关本身工作正常。

### 查看网关日志
bash
# 实时滚动查看日志（推荐）
journalctl -u socketcan-gateway -f

# 查看最近 100 行日志
journalctl -u socketcan-gateway -n 100 --no-pager

# 查看包含错误信息的日志
journalctl -u socketcan-gateway -p err -b

### 配置参数（修改波特率、通道等）
默认配置：通道 1，波特率 500000，数据波特率 2000000，RX接口 vcan_tx，TX接口 vcan_rx。

## 可配置的命令行参数（无需修改源代码）：

-c：UCAN2 通道号（1 或 2）

-r：接收接口名（默认 vcan_tx）

-t：发送接口名（默认 vcan_rx）

-b：CAN 仲裁域波特率（bps，如 125000、250000、500000、1000000）

-d：后台运行（daemon 模式）

-v：详细日志（打印每帧数据）

-i：统计信息打印间隔（秒，默认 10）


### 修改配置步骤
# 编辑 systemd 服务文件
bash
sudo vi /etc/systemd/system/socketcan-gateway.service

# 在 ExecStart 行添加参数，例如：
ini
ExecStart=/opt/socketcan-gateway/socketcan_gateway -d -v -b 250000 -c 2

# 重载并重启服务
bash
sudo systemctl daemon-reload
sudo systemctl restart socketcan-gateway

### 管理网关服务
bash
# 启动
sudo systemctl start socketcan-gateway

# 停止
sudo systemctl stop socketcan-gateway

# 重启
sudo systemctl restart socketcan-gateway

# 查看状态
sudo systemctl status socketcan-gateway

# 设置开机自启
sudo systemctl enable socketcan-gateway

# 禁用开机自启
sudo systemctl disable socketcan-gateway
