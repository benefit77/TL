#!/bin/bash

INSTALL_DIR="/opt/socketcan-gateway"
SERVICE_FILE="/etc/systemd/system/socketcan-gateway.service"

# 创建安装目录
mkdir -p $INSTALL_DIR/libucan2

# 复制文件
cp socketcan_gateway_production $INSTALL_DIR/socketcan_gateway
cp libucan2/*.so $INSTALL_DIR/libucan2/
cp libucan2/*.h $INSTALL_DIR/libucan2/

# 配置环境变量
echo "export LD_LIBRARY_PATH=$INSTALL_DIR/libucan2:\$LD_LIBRARY_PATH" > /etc/profile.d/socketcan-gateway.sh

# ----------------------------------------------------------------------
# 预先创建虚拟 CAN 接口（如果不存在）
echo "正在设置虚拟 CAN 接口..."
modprobe vcan
# 创建 vcan_tx（若已存在则忽略错误）
ip link add dev vcan_tx type vcan 2>/dev/null || true
ip link set vcan_tx up
# 创建 vcan_rx
ip link add dev vcan_rx type vcan 2>/dev/null || true
ip link set vcan_rx up
echo "虚拟接口 vcan_tx 和 vcan_rx 已就绪"
# ----------------------------------------------------------------------

# 创建systemd服务（带 ExecStartPre 自动保活接口）
cat > $SERVICE_FILE <<EOF
[Unit]
Description=SocketCAN Gateway for UCAN2
After=network.target

[Service]
Type=simple
ExecStartPre=/bin/sh -c 'modprobe vcan; ip link add vcan_tx type vcan 2>/dev/null || true; ip link set vcan_tx up; ip link add vcan_rx type vcan 2>/dev/null || true; ip link set vcan_rx up'
ExecStart=$INSTALL_DIR/socketcan_gateway -d -v
Restart=on-failure
Environment=LD_LIBRARY_PATH=$INSTALL_DIR/libucan2
User=root

[Install]
WantedBy=multi-user.target
EOF

# 重载服务
systemctl daemon-reload
systemctl enable socketcan-gateway

echo "安装完成！请运行：systemctl start socketcan-gateway"
echo "测试命令：cansend vcan_tx 123#1122334455667788"
