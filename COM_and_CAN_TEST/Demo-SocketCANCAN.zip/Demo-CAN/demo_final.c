#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include "libucan2/api.h"

static int g_running = 1;
static int g_channel_enabled = 0;

void signal_handler(int sig) {
    if (sig == SIGINT || sig == SIGTERM) {
        printf("\n\n收到信号 %d，正在清理资源...\n", sig);
        g_running = 0;
        if (g_channel_enabled) {
            libucan2_EndisChannel(1, false);
            printf("通道已禁用\n");
        }
        exit(0);
    }
}

int main(void) {
    uint8_t channel = 1;
    uint32_t baud_rate = 500000;
    uint32_t baud_data = 2000000;
    
    printf("========================================\n");
    printf("  libucan2 API Demo \n");
    printf("========================================\n");
    
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    // 在开始时调用Deinit清理上次残留的状态
    printf("\n[步骤1] 清理上次可能残留的状态...\n");
    libucan2_Deinit();
    usleep(500000);  // 等待500ms让设备恢复
    
    printf("\n[步骤2] 初始化库...\n");
    if (!libucan2_Init()) {
        printf("初始化失败\n");
        return -1;
    }
    printf("初始化成功\n");
    
    printf("\n[步骤3] 获取固件版本...\n");
    uint32_t fw_ver = libucan2_GetFirmwareVersion();
    printf("固件版本: %u\n", fw_ver);
    
    printf("\n[步骤4] 先禁用通道 %d...\n", channel);
    libucan2_EndisChannel(channel, false);
    usleep(100000);
    
    printf("\n[步骤5] 初始化通道 %d (波特率: %u/%u)...\n", channel, baud_rate, baud_data);
    if (!libucan2_InitChannel(channel, true, baud_rate, baud_data)) {
        printf("通道初始化失败\n");
        return -1;
    }
    printf("通道初始化成功\n");
    
    printf("\n[步骤6] 启用通道 %d...\n", channel);
    if (!libucan2_EndisChannel(channel, true)) {
        printf("通道启用失败\n");
        return -1;
    }
    g_channel_enabled = 1;
    printf("通道已启用\n");
    
    printf("\n[步骤7] 发送测试帧...\n");
    libucan2_CANFrame frame;
    memset(&frame, 0, sizeof(frame));
    frame.MsgId = 0x123;
    frame.IsStdId = true;
    frame.IsDataFrame = true;
    frame.IsClassicFrame = true;
    frame.DataLength = 8;
    frame.Data[0] = 0x11;
    frame.Data[1] = 0x22;
    frame.Data[2] = 0x33;
    frame.Data[3] = 0x44;
    frame.Data[4] = 0x55;
    frame.Data[5] = 0x66;
    frame.Data[6] = 0x77;
    frame.Data[7] = 0x88;
    
    if (libucan2_SendFrame(channel, &frame)) {
        printf("发送成功\n");
    } else {
        printf("发送失败\n");
    }
    
    printf("\n[步骤8] 接收帧 (5秒超时)...\n");
    int recv_count = 0;
    int timeout = 0;
    
    while (g_running && timeout < 500) {
        memset(&frame, 0, sizeof(frame));
        if (libucan2_RecvFrame(channel, &frame)) {
            recv_count++;
            printf("收到帧 #%d: ID=0x%X, DLC=%d\n", recv_count, frame.MsgId, frame.DataLength);
            timeout = 0;
        } else {
            timeout++;
            usleep(10000);
        }
    }
    
    if (recv_count == 0) {
        printf("未收到帧\n");
    }
    
    printf("\n[步骤9] 清理资源...\n");
    // 只禁用通道，不调用Deinit
    libucan2_EndisChannel(channel, false);
    g_channel_enabled = 0;
    printf("通道已禁用，清理完成\n");
    
    return 0;
}
